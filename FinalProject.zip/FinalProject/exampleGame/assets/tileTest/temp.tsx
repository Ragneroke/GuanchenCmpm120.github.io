<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="temp" tilewidth="32" tileheight="32" tilecount="40" columns="8">
 <image source="0x72_16x16DungeonTileset.v1.png" trans="000000" width="256" height="160"/>
</tileset>
