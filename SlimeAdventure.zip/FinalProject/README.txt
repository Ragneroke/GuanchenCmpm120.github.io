Group 7 Large Soda
------------------
The game canvas is 800x800 so make sure the browser is bigger than this to 
have a better performance to play. 

Game online URL:https://ragneroke.itch.io/slime-adventure
Github version:https://github.com/Ragneroke/cmpm120
