<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="test2" tilewidth="10" tileheight="10" tilecount="86800" columns="350">
 <image source="../../../../../../../Downloads/test-master/test-master/dm.jpg" trans="000000" width="3508" height="2480"/>
</tileset>
